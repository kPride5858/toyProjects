
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextChanger : MonoBehaviour
{
    public Text textBox;

    // Update is called once per frame
    void Update()
    {
        List<int> obj = GameObject.Find("gameMaster").GetComponent <gameRule>().obj;


        textBox.text = obj[int.Parse(this.name)].ToString();
    }
}
