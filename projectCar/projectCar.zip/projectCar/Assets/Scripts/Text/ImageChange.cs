
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ImageChange : MonoBehaviour
{
    public Sprite[] imageChange;
    Image image;
    public GameObject gameMaster;
    // Update is called once per frame
    private void Start()
    {
        image = GetComponent<Image>();
    }
    void Update()
    {
        List<int> obj = gameMaster.GetComponent <gameRule>().obj;
        if (obj[int.Parse(name)] == 1)
        {
            image.sprite = imageChange[0];
        }
        else if (obj[int.Parse(this.name)] == 2)
        {
            image.sprite = imageChange[1];
        }
        else
        {
            image.sprite = imageChange[2];
        }
    }
}
