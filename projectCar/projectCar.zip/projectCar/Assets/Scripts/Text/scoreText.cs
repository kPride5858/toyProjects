
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class scoreText : MonoBehaviour
{
    public Text textbox;
    // Update is called once per frame
    void Update()
    {
        int score = GameObject.Find("gameMaster").GetComponent<gameRule>().score;
        if (SceneManager.GetActiveScene().name == "Play")
        {
            
            textbox.text = score.ToString();
        }
        else
        {
            textbox.text = "����� ������ :\n" + score.ToString()+"!";
        }
    }
}
