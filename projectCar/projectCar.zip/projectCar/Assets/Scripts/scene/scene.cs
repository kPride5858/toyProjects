using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class scene : MonoBehaviour
{
    // Update is called once per frame
    public void SceneChange()
    {
        Destroy(GameObject.Find("gameMaster"));
        SceneManager.LoadScene("Play");
    }
}
