using UnityEngine;
using UnityEngine.SceneManagement;

public class monsterGimmick : MonoBehaviour
{
    GameObject target;
    GameObject master;
    public Sprite[] monsterImage;

    int monsterHp = 10;
    float limitTime = 1;
    Vector3 newScale;
    SpriteRenderer sprite;

    // Start is called before the first frame update
    void Start()
    {

        target = GameObject.Find("target");
        sprite = GetComponent<SpriteRenderer>();

        master = GameObject.Find("gameMaster");

    }

    // Update is called once per frame
    void Update()
    {
        transform.localPosition = new Vector3(-15, 0, 22);
        transform.localRotation = Quaternion.Euler(0, 0, 0);

        master.GetComponent<gameRule>().debugMode = true;
        if (monsterHp > 0)
        {
            newScale = new Vector3(Time.deltaTime, Time.deltaTime, 0);
            transform.localScale += newScale;

            if (transform.localScale.x >= 20)
            {
                SceneManager.LoadScene("GameOver");
            }
        }
        else
        {
            limitTime -= Time.deltaTime;
            sprite.sprite = monsterImage[2];
            if (limitTime > 0)
            {
                master.GetComponent<gameRule>().debugMode = true;

            }
            else
            {
                master.GetComponent<gameRule>().debugMode = false;
                master.GetComponent<gameRule>().score += 1000;
                Destroy(gameObject);
            }
        }

        if (Input.GetMouseButtonDown(0))
        {
            monsterHp--;
            sprite.sprite = monsterImage[1];
        }


    }
}
