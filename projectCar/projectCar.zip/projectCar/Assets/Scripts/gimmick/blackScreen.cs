using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class blackScreen : MonoBehaviour
{
    float timeLimit = 4;
    bool TimeStop;
    public GameObject stop;
    
       
    // Start is called before the first frame update
    void Start()
    {
        TimeStop = stop.GetComponent<stopUI>().TimeStop;
    }
    private void Update()
    {
        timeLimit -= Time.deltaTime;
        if(TimeStop == true || timeLimit<=0)
        {
            timeLimit = 4;
            gameObject.SetActive(false);
        }
    }
}
