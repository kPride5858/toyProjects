using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class gameRule : MonoBehaviour
{
    public List<int> obj = new List<int> { };
    public int score = 0;
    public int hp = 3;

    public GameObject TL;
    public GameObject[] hpbar;
    public GameObject[] car;
    public void Success()
    {
        TL.GetComponent<timeLeft>().time = 3;
        obj[0] = obj[1];
        obj[1] = obj[2];
        obj[2] = Random.Range(1, 4);
        score += 100;
    }
    public void failed()
    {
        TL.GetComponent<timeLeft>().time = 3;
        hp -= 1;
        for (int i = 0; i < hpbar.Length; i++)
        {
            if (hpbar[i].GetComponent<Image>().color != Color.black)
            {
                hpbar[i].GetComponent<Image>().color = Color.black;
                break;
            }
        }
        if (hp <= 0)
        {
            Debug.Log("���ӿ���");
        }
        obj[0] = obj[1];
        obj[1] = obj[2];
        obj[2] = Random.Range(1, 4);
    }
    private void Start()
    {
        for (int i = 1; i<car.Length; i++)
        { 
            car[i].SetActive(false);
        }
        hpbar = GameObject.FindGameObjectsWithTag("hp");
        for (int i =0;i<hpbar.Length;i++)
        {
            hpbar[i].GetComponent<SpriteRenderer>();
        }
        for (int i = 0; i < 3;i++)
        {
            obj.Add(Random.Range(1, 4)); 
        }
    }
    void Update()
    {
        for (int i = obj.Count; i > 3; i--)
        {
            obj.RemoveRange(3,obj.Count-3);
        }
        if (Input.GetMouseButtonDown(0))
        {
            
            Vector3 mouseP = Input.mousePosition;
            if (mouseP.x <= Screen.width / 3) //��
            {
                car[0].transform.position = new Vector3(car[1].transform.position.x,car[0].transform.position.y, car[0].transform.position.z);
                if(obj[0] == 1)
                {
                    Success();
                }
                else
                {
                    failed();
                }


            }
            else if (mouseP.x >= Screen.width / 3 && mouseP.x <= Screen.width / 3 * 2) //��
            {
                car[0].transform.position = new Vector3(car[2].transform.position.x, car[0].transform.position.y, car[0].transform.position.z);
                if (obj[0] == 2)
                {
                    Success();
                }
                else
                {
                    failed();
                }

            }
            else if (mouseP.x >= Screen.width / 3 * 2) //��
            {
                car[0].transform.position = new Vector3(car[3].transform.position.x, car[0].transform.position.y, car[0].transform.position.z);
                if (obj[0] == 3)
                {
                    Success();
                }
                else
                {
                    failed();
                }

            }

        }
    }
}
