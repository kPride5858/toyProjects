using UnityEngine;

public class mainMenu : MonoBehaviour
{
    public bool main = true;

    public GameObject playObj;
    public GameObject mainObj;
    // Start is called before the first frame update

    // Update is called once per frame
    void Update()
    {
        if (main == true)
        {
            Time.timeScale = 0;
            playObj.SetActive(false);
            mainObj.SetActive(true);
        }
        else
        {
            
            playObj.SetActive(true);
            mainObj.SetActive(false);
        }
    }
}
