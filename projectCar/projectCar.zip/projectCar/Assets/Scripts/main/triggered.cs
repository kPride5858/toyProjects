using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class triggered : MonoBehaviour
{
    public GameObject gameMaster;

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "obstacle")
        {
            gameMaster.GetComponent<gameRule>().failed();
        }
    }
}
