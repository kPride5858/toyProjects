using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class carMove : MonoBehaviour
{
    public float speed;
    public float sec = 0;

    // Update is called once per frame
    void Update()
    {
        sec += Time.deltaTime;
        if (sec >= 1 && speed < 45)
        {
            speed += 0.5f;
            sec = 0;
        }
        transform.position += new Vector3(0, 0, speed * Time.deltaTime);
    }
}
