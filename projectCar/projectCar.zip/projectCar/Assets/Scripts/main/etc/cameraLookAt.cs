using UnityEngine;

public class cameraLookAt : MonoBehaviour
{
    GameObject target;
    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.Find("target");
    }

    // Update is called once per frame
    void Update()
    {
        float speed = target.GetComponent<carMove>().speed;
        transform.LookAt(target.transform.position);
        if (transform.position.z < 200 && speed >= 35)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z + speed * 0.0053f + speed * Time.deltaTime * 0.001f);
        }
        else
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, target.transform.position.z - 18);
        }


    }
}
