using UnityEngine;

public class cameraLookAt : MonoBehaviour
{
    GameObject target;
    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.Find("target");
    }

    // Update is called once per frame
    void Update()
    {
        float speed = target.GetComponent<carMove>().speed;
        
        if (speed >= 35 && transform.position.y < 26 + speed * 0.3f)
        {
            transform.position = new Vector3(transform.position.x - speed * Time.deltaTime * 0.08f, transform.position.y + speed * Time.deltaTime * 0.05f, target.transform.position.z - 18);
        }
        else
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, target.transform.position.z - 18);
        }
        transform.LookAt(target.transform.position);

    }
}
