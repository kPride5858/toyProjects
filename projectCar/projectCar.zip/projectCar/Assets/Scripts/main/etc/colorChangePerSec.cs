using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class colorChangePerSec : MonoBehaviour
{
    public GameObject TL;
    Color color;
    float time;
    // Start is called before the first frame update
    void Start()
    {
        color = GetComponent<Renderer>().material.color;
        
    }

    // Update is called once per frame
    void Update()
    {
        time = TL.GetComponent<timeLeft>().time;
        if (time <= 1)
        {
            if (time >= -0.25f && color.a < 0.9)
            {
                color.a += 1.5f * Time.deltaTime;
            }
            else
            {
                color.a -= 3f * Time.deltaTime;
            }
            GetComponent<Renderer>().material.color = color;
        }
        else
        {
            color.a = 0;
            GetComponent<Renderer>().material.color = color;

        }
    }
}
