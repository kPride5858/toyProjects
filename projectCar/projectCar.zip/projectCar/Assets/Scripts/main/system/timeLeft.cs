using UnityEngine;
using UnityEngine.SceneManagement;
public class timeLeft : MonoBehaviour
{
    public float time = 3;
    public float speed;
    public float timeSpeed = 0;
    public GameObject target;
    // Start is called before the first frame update
    private void Start()
    {
        speed = target.GetComponent<carMove>().speed;
    }
    // Update is called once per frame
    void Update()
    {
        if (SceneManager.GetActiveScene().name == "Play")
        {
            if (timeSpeed < 0.003)
            {
                timeSpeed += speed * Time.deltaTime / 500000;
            }

            time -= Time.deltaTime + timeSpeed;
            if (Mathf.Round(time) < 0)
            {
                GetComponent<gameRule>().failed();
                time = 3;

            }
        }

    }
}
