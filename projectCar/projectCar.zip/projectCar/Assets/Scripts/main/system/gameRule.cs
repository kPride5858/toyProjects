using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class gameRule : MonoBehaviour
{
    public bool debugMode = false;
    public List<int> obj = new List<int> { };
    public int score = 0;
    public int hp = 3;

    public GameObject[] hpbar;
    public GameObject[] car;

    public void Success()
    {
        GetComponent<timeLeft>().time = 3;
        obj[0] = obj[1];
        obj[1] = obj[2];
        obj[2] = Random.Range(1, 3);
        score += 100;
    }
    public void failed()
    {
        if (debugMode == false && Time.timeScale >= 1)
        {
            GetComponent<timeLeft>().time = 3;
            hp -= 1;
            for (int i = 0; i < hpbar.Length; i++)
            {
                if (hpbar[i].GetComponent<Image>().color != Color.black)
                {
                    
                    hpbar[i].GetComponent<Image>().color = Color.black;
                    break;
                }
            }
            if (hp <= 0)
            {
                SceneManager.LoadScene("GameOver");
            }
            obj[0] = obj[1];
            obj[1] = obj[2];
            obj[2] = Random.Range(1, 3);
        }
    }
    private void Start()
    {
 

        DontDestroyOnLoad(gameObject);
        for (int i = 1; i<car.Length; i++) // �ٸ� �ڵ��� ��Ȱ��ȭ
        { 
            car[i].SetActive(false);
        }
        hpbar = GameObject.FindGameObjectsWithTag("hp");
        for (int i =0;i<hpbar.Length;i++) //���� ��������Ʈ ������ �ҷ�����
        {
            hpbar[i].GetComponent<SpriteRenderer>();
        }
        for (int i = 0; i < 3;i++) //obj����Ʈ�� ���� �� �߰�
        {
            obj.Add(Random.Range(1, 3)); 
        }
    }
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.LeftControl))
        {
            Debug.Log("����׸��");
            debugMode = true;
        }
        if (SceneManager.GetActiveScene().name == "Play")
        {
            for (int i = obj.Count; i > 3; i--)
            {
                obj.RemoveRange(3, obj.Count - 3);
            }
        }
    }
}
