using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class deco : MonoBehaviour
{
    public GameObject target;
    public GameObject plane;
    // Update is called once per frame
    void Update()
    {
        if (transform.position.z < target.transform.position.z - 70 && name != "wood")
        {
            plane.GetComponent<decoCreator>().decoRange--;
            Destroy(gameObject);

        }
    }
}
