using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class deco : MonoBehaviour
{
    public GameObject target;
    public GameObject plane;
    public GameObject cameraObject;
    // Update is called once per frame
    void Update()
    {
        transform.rotation = cameraObject.transform.rotation;
        if (transform.position.z < target.transform.position.z - 70 && name != "wood")
        {
            plane.GetComponent<decoCreator>().decoRange--;
            Destroy(gameObject);

        }
    }
}
