using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class deco : MonoBehaviour
{
    public GameObject target;
    // Update is called once per frame
    void Update()
    {
        if (transform.position.z < target.transform.position.z - 55)
        {
            Destroy(gameObject);
        }
    }
}
