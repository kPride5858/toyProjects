using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class decoCreator : MonoBehaviour
{
    GameObject[] deco = new GameObject[1];
    public GameObject[] decoWillBeCreated;
    public int decoNum;
    public int decoRange = 0;
    // Start is called before the first frame update

    // Update is called once per frame
    void Update()
    {
        
        if(decoRange < 10)
        {
            deco = GameObject.FindGameObjectsWithTag("deco");
            decoNum = Random.Range(0, decoWillBeCreated.Length);
            decoRange+=2;
            Instantiate(decoWillBeCreated[decoNum], new Vector3(Random.Range(-25,-18),0,transform.position.z + Random.Range(0,300)), transform.rotation);
            Instantiate(decoWillBeCreated[decoNum], new Vector3(Random.Range(25, 18), 0, transform.position.z + Random.Range(0, 300)), transform.rotation);
        }
    }
}
