using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class decoCreator : MonoBehaviour
{
    GameObject[] deco = new GameObject[1];
    public GameObject[] decoWillBeCreated;
    public int decoNum;
    // Start is called before the first frame update

    // Update is called once per frame
    void Update()
    {
        
        if(deco.Length<5)
        {
            deco = GameObject.FindGameObjectsWithTag("deco");
            Debug.Log(deco.Length);
            decoNum = Random.Range(0, decoWillBeCreated.Length);
            Instantiate(decoWillBeCreated[decoNum], new Vector3(Random.Range(-25,-18),-7,transform.position.z + Random.Range(0,300)), Quaternion.Euler(-90,0,0));
        }
    }
}
