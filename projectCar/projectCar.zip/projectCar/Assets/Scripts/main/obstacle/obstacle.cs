using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class obstacle : MonoBehaviour
{
    int obj;
    bool a = false;

    public GameObject[] car;
    GameObject gameMaster;
    // Start is called before the first frame update
    void Start()
    {
        gameMaster = GameObject.FindGameObjectWithTag("GameController");
    }

    // Update is called once per frame
    void Update()
    {
        if (a == false)
        {
            obj = gameMaster.GetComponent<gameRule>().obj[0];
            a = true;
        }
        if(obj == 1)
        {
            transform.position = new Vector3(car[0].transform.position.x, transform.position.y, transform.position.z);
        }
        else if(obj == 2)
        {
            transform.position = new Vector3(car[1].transform.position.x, transform.position.y, transform.position.z);
        }
        else
        {
            transform.position = new Vector3(car[2].transform.position.x, transform.position.y, transform.position.z);
        }
    }
}
