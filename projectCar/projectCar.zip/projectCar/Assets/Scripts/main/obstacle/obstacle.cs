
using UnityEngine;

public class obstacle : MonoBehaviour
{
    int obj;
    bool a = false;

    GameObject target;
    public GameObject[] car;
    GameObject gameMaster;

    void Start()
    {
        gameMaster = GameObject.FindGameObjectWithTag("GameController");
        target = GameObject.Find("target");
    }

    void Update()
    {
        if (a == false)
        {
            obj = gameMaster.GetComponent<gameRule>().obj[0];
            a = true;
        }

        if(obj == 1)
        {
            transform.position = new Vector3(car[0].transform.position.x, transform.position.y, transform.position.z);
        }
        else if(obj == 2)
        {
            transform.position = new Vector3(car[1].transform.position.x, transform.position.y, transform.position.z);
        }

        if(transform.position.z < target.transform.position.z - 55)
        {
            Destroy(gameObject);
        }
    }
}
