using UnityEngine;
using UnityEngine.SceneManagement;

public class obstacleCreater : MonoBehaviour
{
    public GameObject[] obs;
    public GameObject timeLeft;
    public GameObject target;
    public GameObject car;
    public int monsterN;
    public float sec = 3;
    // Update is called once per frame
    void Update()
    {
        if (SceneManager.GetActiveScene().name == "Play")
        {
            float time = timeLeft.GetComponent<timeLeft>().timeSpeed * 2f;
            if (target.transform.position.z >= 400)
            {
                monsterN = Random.Range(0, obs.Length);
                sec -= Time.deltaTime + time;
                if (sec <= 0)
                {
                    Instantiate(obs[monsterN], new Vector3(0, -4, car.transform.position.z + 200), transform.rotation);
                    sec = 3;
                }
            }
        }

    }

}
