using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class obstacleCreater : MonoBehaviour
{
    public GameObject[] obs;
    public GameObject time;
    public GameObject car;
    public int monsterN;
    float sec;
    // Start is called before the first frame update
    void Start()
    {
        sec = time.GetComponent<carMove>().sec;
    }

    // Update is called once per frame
    void Update()
    {
        monsterN = Random.Range(0, obs.Length);
        sec = time.GetComponent<carMove>().sec;
        if (sec <= 0)
        {
            Instantiate(obs[monsterN],new Vector3(0,0,car.transform.position.z + 200),Quaternion.identity);
        }
    }
}
