using UnityEngine;
using UnityEngine.SceneManagement;

public class obstacleCreater : MonoBehaviour
{
    public GameObject[] obs;
    public GameObject target;
    public GameObject car;
    int monsterN;
    public float speed = 0;
    public float sec = 0;
    // Update is called once per frame
    void Update()
    {
        if (SceneManager.GetActiveScene().name == "Play")
        {
            if (target.transform.position.z >= 300)
            {
                if(speed <= 2.4f)
                {
                    speed += target.GetComponent<carMove>().speed * Time.deltaTime / 1000;
                }
               
                sec -= Time.deltaTime * speed;
                if (sec <= 0)
                { 
                    monsterN = Random.Range(0, obs.Length);
                    Instantiate(obs[monsterN], new Vector3(0, -4, car.transform.position.z + 200), transform.rotation);
                    sec = 3;
                }
            }
        }

    }

}
