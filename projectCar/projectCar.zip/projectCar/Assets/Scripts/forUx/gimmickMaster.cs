using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gimmickMaster : MonoBehaviour
{
    public GameObject target;
    public GameObject[] gimmick;
    public GameObject cameraObject;
    public int gimmickNum;

    float time = 0;
    float speed;
    //ī�޶���1��(������ȯ) cameraLookAt ��ũ��Ʈ�� ����
    private void Update()
    {
        
        speed = target.GetComponent<carMove>().speed;
        
        if (speed > 35)
        {
            time -= Time.deltaTime;
            if (time <= 0)
            {
                gimmickNum = Random.Range(0, gimmick.Length);

                switch (gimmickNum)
                {
                    case 0:
                        gimmick[0].transform.localScale = new Vector3 (Random.Range(0, 13), Random.Range(1.2f, 7), 1);
                        gimmick[0].SetActive(true);
                        break;
                    case 1:

                        Instantiate(gimmick[1]).transform.parent = cameraObject.transform;
                        break;
                }

                time = 10;
            }
        }
        
        
    }

}
