using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gimmickMaster : MonoBehaviour
{
    public GameObject target;
    public GameObject[] gimmick;
    float time = 0;
    int gimmickNum;
    float speed;
    //ī�޶���1��(������ȯ) cameraLookAt ��ũ��Ʈ�� ����
    private void Update()
    {
        
        speed = target.GetComponent<carMove>().speed;
        
        if (speed > 35)
        {
            time -= Time.deltaTime;
            if (time <= 0)
            {
                gimmickNum = Random.Range(0, gimmick.Length);

                switch (gimmickNum)
                {
                    case 0:
                        gimmick[0].transform.localScale = new Vector3 (Random.Range(0, 13), Random.Range(0, 4.1f), 1);
                        gimmick[0].SetActive(true);
                        break;
                }

                time = 10;
            }
        }
        
        
    }

}
