using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartUi : MonoBehaviour
{
    public GameObject mainSceneChanger;
    public GameObject camera;
    // Start is called before the first frame update
    public void play()
    {
        
        camera.transform.position = new Vector3(0, 8 , -18);
        Time.timeScale = 1;
        mainSceneChanger.GetComponent<mainMenu>().main = false;
        
    }
}
