
using UnityEngine;
using UnityEngine.SceneManagement;

public class stopUI : MonoBehaviour
{
    public GameObject[] inter;
    public GameObject black;
    public GameObject master;
    public bool TimeStop = false;
    public void Start()
    {
        if (name != "stop")
        {
            
            gameObject.SetActive(false);
        }
    }
    public void Stop()
    {
        for (int i = 0;i<inter.Length;i++)
        {
            TimeStop = true;
            black.SetActive(true);
            inter[i].SetActive(true);
        }
        Time.timeScale = 0;
        
    }
    public void Continue()
    {
        Time.timeScale = 1;
        for (int i = 0; i < inter.Length; i++)
        {
            TimeStop = false;
            inter[i].SetActive(false);
            black.SetActive(false);
        }
    }
    public void Restart()
    {
        Time.timeScale = 1;
        Destroy(master);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        
    }
}
