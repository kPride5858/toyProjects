using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    public GameObject[] car;
    public GameObject master;
    List<int> obj;
    // Start is called before the first frame update
    void Start()
    {
        obj = master.GetComponent<gameRule>().obj;
    }

    // Update is called once per frame
    public void MLeft()
    {
        car[0].transform.position = new Vector3(car[1].transform.position.x, car[0].transform.position.y, car[0].transform.position.z);
        if (obj[0] == 1)
        {
            master.GetComponent<gameRule>().Success();
        }
        else
        {
            master.GetComponent<gameRule>().failed();
        }
    }
    public void MMiddle()
    {
        car[0].transform.position = new Vector3(car[2].transform.position.x, car[0].transform.position.y, car[0].transform.position.z);
        if (obj[0] == 2)
        {
            master.GetComponent<gameRule>().Success();
        }
        else
        {
            master.GetComponent<gameRule>().failed();
        }
    }
    public void MRight()
    {
        car[0].transform.position = new Vector3(car[3].transform.position.x, car[0].transform.position.y, car[0].transform.position.z);
        if (obj[0] == 3)
        {
            master.GetComponent<gameRule>().Success();
        }
        else
        {
            master.GetComponent<gameRule>().failed();
        }

    }
}
