using UnityEngine;

public class cameraLookAt : MonoBehaviour
{
    public GameObject target; 
    float speed;
   
    public void cameraGimmick()
    {
        transform.position = new Vector3(transform.position.x - speed * Time.deltaTime * 0.08f, transform.position.y + speed * Time.deltaTime * 0.05f, target.transform.position.z - 18);
    }

    // Update is called once per frame
    void Update()
    {
        speed = target.GetComponent<carMove>().speed;
        
        if (speed >= 35 && transform.position.y < 26 + speed * 0.3f)
        {
            cameraGimmick();
        }
        else
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, target.transform.position.z - 18);
        }
        transform.LookAt(target.transform.position);

    }
}
